# -*- coding: utf-8 -*-
"""
Created on Thu Sep 27 09:46:03 2018
2018/9/27　YHD　中田
データ加工処理のみ実行する用
@author: 00000010
"""
import PreProcess.preprocess as proc

# データ加工
proc.make_modeling_data()
