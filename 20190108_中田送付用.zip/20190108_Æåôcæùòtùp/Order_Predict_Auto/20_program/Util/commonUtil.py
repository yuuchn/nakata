# -*- coding: utf-8 -*-
"""
Created on Tue Jul 31 09:53:21 2018

共通処理
@author: 00000010
"""

import datarobot as dr
import datetime
import pandas as pd


"""
パーティショニング設定（モデル作成時の事前設定）
利用可能なオプション
・datetime_partition_column：（str）パーティション分割で利用するカラム名
・use_time_series：（boolean）時系列オプションを利用するかどうか
・number_of_backtests：（int）バックテストの数
・feature_derivation_window_start：（int）予測ポイント前日（開始）
・feature_derivation_window_end：（int）予測ポイント前日（終了）
・forecast_window_start：（int）予測ポイント後日（開始）
・forecast_window_end：（int）予測ポイント後日（終了）
"""
def DatetimePartitioningSpecification(
        datetime_partition_column
        ,use_time_series
        ,feature_settings
        ,number_of_backtests
        ,feature_derivation_window_start
        ,feature_derivation_window_end
        ,forecast_window_start
        ,forecast_window_end):
    
    timeSeries = dr.DatetimePartitioningSpecification(
            datetime_partition_column=datetime_partition_column
            ,use_time_series=use_time_series
            ,feature_settings=feature_settings
            ,number_of_backtests=number_of_backtests
            ,feature_derivation_window_start=feature_derivation_window_start
            ,feature_derivation_window_end=feature_derivation_window_end
            ,forecast_window_start=forecast_window_start
            ,forecast_window_end=forecast_window_end)
    return timeSeries

"""
モデル取得
プロジェクトID、モデルIDを指定してモデル取得
"""
def get_Model(project_id, model_id):
    return dr.Model.get(project=project_id, model_id=model_id)

"""
第何週目、曜日を返却
本日日付を取得し、週目・曜日を返却
"""
def get_weekday():
    # 本日日付を取得
    day = datetime.date.today().day
    # 本日の「曜日」取得
    wd = ["月","火","水","木","金","土","日"]
    weekday = wd[datetime.date.today().weekday()]
    
    # 1週間前の日付が同月かどうかを判定
    weeks = 0
    while day > 0:
        weeks += 1
        day -= 7

#    result = False
#    # 第一週目　且つ 木曜日の場合は芯を
#    if (weeks == 1 and weekday == "木"):
#        result = True
    return weeks, weekday

"""
プロジェクトの取得
プロジェクトを既に作成している場合は、プロジェクトのIDを指定して、プロジェクトを取得する。
"""
def get_project(projectId):
    project = dr.Project.get(project_id=projectId)
    return project