# -*- coding: utf-8 -*-
"""
Created on Tue Jul 31 09:53:21 2018

各種設定値
@author: YHD 中田
"""

# APIトークン（適切な利用ユーザのトークンを設定して下さい。）
my_token="jNewPlw_dOvAM3JcaIlEYff3vAv08i_M"

# DAtaRobotサーバURL
endpoint='http://10.0.166.146/api/v2/'
