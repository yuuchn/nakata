# -*- coding: utf-8 -*-
"""
Created on Tue Jul 31 09:53:21 2018

メイン処理
@author: 00000010
"""
root = "C:\\Users\\YLCICTW71-CL\\Desktop\\Order_Predict_Auto_Dev"
# プログラムルートディレクトリ
rootDir = root + "\\20_program"
# データルートディレクトリ
dataDir = root + "\\10_data"
# 予測結果出力ルートディレクトリ
predictDir = root + "\\30_prediction"

import os
import glob
os.chdir(rootDir)

import pandas as pd
import datetime
from datetime import timedelta
import datarobot as dr
import PreProcess.preprocess as proc
import Properties.properties as pr
import Util.commonUtil as util

"""
メイン処理開始
"""
# データ加工
proc.make_modeling_data()

# 接続設定
c=dr.Client(token=pr.my_token, endpoint=pr.endpoint)

# 「10_データ」ディレクトリのフォルダ一覧取得
dirList = os.listdir(dataDir)
dirList.pop(0) # 「00_common」は除外

# 汎用マスタ読込み
projectDf = pd.read_csv(rootDir+"\\hanyoMst.csv", index_col=0)


for tmpDir in dirList:
    # ディレクトリ内より「*_modeling_*」データ一覧取得（ソート）
    modeling_file_list = sorted(glob.glob(dataDir+"\\"+tmpDir+"\\*_modeling_*.csv"))
    # ディレクトリ内より「*prediction_*」データ一覧取得（ソート）
    prediction_file_list = sorted(glob.glob(dataDir+"\\"+tmpDir+"\\*_prediction_*.csv"))
    # 「モデル構築／予測」のファイル名取得
    modeling_file_full = modeling_file_list[len(modeling_file_list)-1]
    prediction_file_full = prediction_file_list[len(prediction_file_list)-1]
    modeling_file = os.path.basename(modeling_file_list[len(modeling_file_list)-1])
    prediction_file = os.path.basename(prediction_file_list[len(prediction_file_list)-1])
    
    # 月初の第一週目　且つ　木曜日判定
    weeks, weekday = util.get_weekday()
    
    # 月初の第一週目　且つ　金曜日判定の場合は、モデル強制更新
    # 前日（木曜日）のバッチ処理のリカバリー
    if (weeks == 1 and weekday == "金"):
        weeks = 1
        weekday = "木"
    
    # モデル強制更新フラグ
    if projectDf.at[tmpDir+"_"+"force_model_refresh", "value"] == "1":
        weeks = 1
        weekday = "木"

    if (weeks == 1 and weekday == "木"):
        """
        モデル構築
        """
        # 学習データ取得
        input_file = modeling_file_full
        # プロジェクト名の設定
        project_name = modeling_file.split(".")[0]
        # 時系列用学習データアップロード（プロジェクト作成）
        project=dr.Project.create(input_file, project_name)
        # プロジェクトID取得
        project_id = project.id
        # 汎用マスタ読込み
        projectDf = pd.read_csv(rootDir+"\\hanyoMst.csv", index_col=0)
        # プロジェクトID書換え
        projectDf.at[tmpDir+"_projectId", "value"] = project_id
        # 汎用マスタ書込み
        projectDf.to_csv(rootDir+"\\hanyoMst.csv")
        # 事前に知りえる特徴量
        FeatureSettings = dr.FeatureSettings(feature_name="休暇日数",a_priori=True)
        # パーティショニングを時系列へ設定
        timeSeries = util.DatetimePartitioningSpecification(
                datetime_partition_column="DateTime"
                ,use_time_series=True
                ,feature_settings=[FeatureSettings]
                ,number_of_backtests=3
                ,feature_derivation_window_start=-28
                ,feature_derivation_window_end=-1
                ,forecast_window_start=4
                ,forecast_window_end=10)
        
        # パーティショニングを引数に与えオートパイロット実行
        # 最適化されたモデルを追加
        project.set_target("count", partitioning_method=timeSeries,
                           advanced_options=dr.helpers.AdvancedOptions(accuracy_optimized_mb=True))
        
        # オートパイロットが終了するまで待つ設定
        project.wait_for_autopilot()
        
        # 汎用マスタより抽出モデル名を取得
        searchMoldelNm = projectDf.at[tmpDir+"_modelNm", "value"]
        # モデルリスト取得
        models = project.get_models(order_by=["metric"],search_params={"name":searchMoldelNm})
        # 最も精度良いモデルを取得
        model = models[len(models)-1]
        # モデルID書込み
        projectDf.at[tmpDir+"_modelId", "value"] = model.id
        projectDf.to_csv(rootDir+"\\hanyoMst.csv")

    """
    予測
    """
    # 汎用マスタ読込み
    projectDf = pd.read_csv(rootDir+"\\hanyoMst.csv", index_col=0)
    # プロジェクトID読込み
    project_id = projectDf.at[tmpDir+"_projectId", "value"]
    # モデルID読込み
    model_id = projectDf.at[tmpDir+"_modelId", "value"]
    # プロジェクトの取得
    project = util.get_project(project_id)
    # モデル取得
    model = util.get_Model(project_id=project_id, model_id=model_id)
    
    # 予測の相対ポイント
    forecast_point = datetime.datetime.today()
    # 金曜日の場合は前日日付を予測実施日とする。
    if (weekday == "金"):
        forecast_point = forecast_point - timedelta(days=1)
    forecast_point = forecast_point.replace(hour=0, minute=0, second=0)
    """
    TODO テスト用日付設定
    """
#    forecast_point = datetime.datetime.strptime("2018-12-27", "%Y-%m-%d")
    
    # 予測ファイル読み込み（チェック用データ）
    data_predict_check = pd.read_csv(prediction_file_full, encoding="sjis")
    # 日付型変換
    data_predict_check['DateTime'] = data_predict_check["DateTime"].apply(lambda x: pd.to_datetime(str(x), format='%Y-%m-%d'))
    # 予測対象日のデータ件数カウント（予測実施日の4日後～10日後）
    check_count = len(data_predict_check[data_predict_check["DateTime"] >= forecast_point + timedelta(days=4)])
    if check_count > 0:
        # 本番データをアップロードし予測
        upload=project.upload_dataset(prediction_file_full,forecast_point=forecast_point)
        pred_job = model.request_predictions(upload.id)
        predictions = pred_job.get_result_when_complete()
        # 予測結果を保存
        predictions.to_csv(predictDir+"\\"+tmpDir+"\\"+prediction_file, index=False)
