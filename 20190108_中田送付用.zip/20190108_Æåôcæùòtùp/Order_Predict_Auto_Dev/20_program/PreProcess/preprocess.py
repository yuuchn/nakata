# -*- coding: utf-8 -*-
"""
出荷オーダー数予測
データ加工

"""
# モジュールインポート
import glob, os
import pandas as pd
import datetime
from dateutil.relativedelta import relativedelta
from datetime import timedelta

def make_modeling_data():
    
    """
    定数
    """
    # データルートディレクトリ
    dataDir = "C:\\Users\\YLCICTW71-CL\\Desktop\\Order_Predict_Auto_Dev\\10_data"
    # 祝日ファイル
    holidayFile = dataDir+"\\00_common\\holiday.txt"
    
    shipmentsList = [u"2日前",u"3日前",u"4日前",u"5日前",u"6日前",u"7日前",u"8日前"]
    """
    TODO 不要？
    #以下特徴量_リストに追加することで特徴量を増やせる
    mAvgList5days = [u"移動平均_5days_1"]
    mAvgList25days = [u"移動平均_25days_1"]
    mAvgList75days = [u"移動平均_75days_1"]
    mMedianList25days = [u"中央値_25days_1"]
    mMaxList25days = [u"最大値_25days_1"]
    mMinList25days = [u"最小値_25days_1"]
    mStdList25days = [u"標準偏差_25days_1"]
    diffAvgList25days = [u"差分平均値_25days_1"]
    diffAvgList5days = [u"差分平均値_5days_1"]
    diffAvgList1days = [u"差分平均値_1days_1"]
    """    
    # 「10_データ」ディレクトリのフォルダ一覧取得
    dirList = os.listdir(dataDir)
    dirList.pop(0) # 「00_common」は除外
    
    """
    処理開始
    """
    for tmpTarget in dirList:
        # ディレクトリ内より「*_row*」データ一覧取得（ソート）
        data_list = sorted(glob.glob(dataDir+"\\"+tmpTarget+"\\*_row*.csv"))
        # 加工用データ取得
        data_full = data_list[len(data_list)-1]
    
        # 加工用データ読込み
        data = pd.read_csv(data_full, "r", encoding="shift_jis", header=0, delimiter=",")
    
        # 欠損値のある行を除く
        data = data.dropna()
        # 出荷日をint型変換
        data["date"] = data["date"].astype(int)
        
        # 日付型変換
        data['DateTime'] = data["date"].apply(lambda x: pd.to_datetime(str(x), format='%Y%m%d'))
        #直近n日の実績
        for i,l in enumerate(shipmentsList):
            data[l] = data["count"].shift(int(i)+2)
    
        # 移動平均の算出
        s = pd.Series(data["count"])
        # 移動平均の算出(ただし区間1のみ使用)
        data[u"移動平均_5days"] = s.rolling(window=5, center=True).mean()
        data[u"移動平均_25days"] = s.rolling(window=25, center=True).mean()
        data[u"移動平均_75days"] = s.rolling(window=75, center=True).mean()
        
        #25日間の中央値
        data[u"中央値_25days"] = s.rolling(window=25).median()
        #25日間の最大値
        data[u"最大値_25days"] = s.rolling(window=25).max()
        #25日間の最小値
        data[u"最小値_25days"] = s.rolling(window=25).min()
        #25日間の標準偏差
        data[u"標準偏差_25days"] = s.rolling(window=25).std()
        #移動平均用に用意したsを使用して差分を取得
        data[u"変化値"] = s - s.shift()
        s = pd.Series(data[u"変化値"])
        #差分の5日平均
        data[u"変化値_5days"] = s.rolling(window=5).mean()
        #差分の25日平均
        data[u"変化値_25days"] = s.rolling(window=25).mean()
        # 直近の休暇日数
        data["前回日付"] = data["DateTime"].shift(1)
        data["休暇日数"] = data["DateTime"] - data["前回日付"]
        data["休暇日数"] = data["休暇日数"].apply(lambda x: x.days-1)
    
        """
        TODO 不要？
        # 移動平均
        for i,l in enumerate(mAvgList5days):
            data[l] = data[u"移動平均_5days"].shift(int(i)+4)
        for i,l in enumerate(mAvgList25days):
            data[l] = data[u"移動平均_25days"].shift(int(i)+14)
        for i,l in enumerate(mAvgList75days):
            data[l] = data[u"移動平均_75days"].shift(int(i)+39)
        # 中央値
        for i,l in enumerate(mMedianList25days):
            data[l] = data[u"中央値_25days"].shift(int(i)+2)
        # 最大値
        for i,l in enumerate(mMaxList25days):
            data[l] = data[u"最大値_25days"].shift(int(i)+2)
        # 最小値
        for i,l in enumerate(mMinList25days):
            data[l] = data[u"最小値_25days"].shift(int(i)+2)
        # 標準偏差
        for i,l in enumerate(mStdList25days):
            data[l] = data[u"標準偏差_25days"].shift(int(i)+2)
        # 変化量
        for i,l in enumerate(diffAvgList1days):
            data[l] = data[u"変化値"].shift(int(i)+2)
        # 変化量（5日間）
        for i,l in enumerate(diffAvgList5days):
            data[l] = data[u"変化値_5days"].shift(int(i)+4)
        # 変化量（25日間）
        for i,l in enumerate(diffAvgList25days):
            data[l] = data[u"変化値_25days"].shift(int(i)+4)
        """
        
        #祝日フラグ用ファイル読み込み
        holiday = pd.read_csv(holidayFile, "r", encoding="shift_jis", header=0, delimiter=",")
        holiday['holiday_flag'] = True
        data = pd.merge(data, holiday, on="date", how="left")
        data[u'holiday_flag'][data[u'holiday_flag'].isnull()] = False
        
        # work用列の削除
        del data["date"]
        del data["前回日付"]
        
        thisMonth = datetime.date.today()
        """
        TODO テスト用(thisMonth)
        """
#        thisMonth = datetime.datetime.strptime("2018-12-27", "%Y-%m-%d")
        
        # 月初
        firstDay = datetime.date.strftime(thisMonth.replace(day=1), '%Y-%m-%d')
        # 月末
        lastDay =  datetime.date.strftime((thisMonth + relativedelta(months=1)).replace(day=1) - timedelta(days=1), '%Y-%m-%d')
        
        # 本日の年取得
        year = str(thisMonth.year)
        # 本日の月取得
        month = str(thisMonth.month).zfill(2)
        # 予測開始日
        startday = thisMonth + datetime.timedelta(days=4)
        endday = thisMonth + datetime.timedelta(days=10)
    
        preStrYear = str(startday.year)
        preStrMonth = str(startday.month).zfill(2)
        preStrDay = str(startday.day).zfill(2)
    
        preEndYear = str(endday.year)
        preEndMonth = str(endday.month).zfill(2)
        preEndDay = str(endday.day).zfill(2)
    
        # モデル構築用ファイル名
        modeling_file = os.path.basename(data_list[len(data_list)-1])
        modelingNm = modeling_file.split("_")[0]+"_modeling_"+year+month+".csv"
        # 予測用ファイル名
        predicitonNm = modeling_file.split("_")[0]+"_prediction_"+preStrYear+preStrMonth+preStrDay+"-"+preEndYear+preEndMonth+preEndDay+".csv"
        
        # 予測用データ
        baseDate = datetime.date.strftime(thisMonth.replace(day=1) - datetime.timedelta(days=35), '%Y-%m-%d')
        predictionData = data[(data[u'DateTime'] >= baseDate) & (data[u'DateTime'] <= lastDay)]
        # 未来予測用の行作成
        idx=[0,1,2,3,4,5,6,7,8,9,10]
        insertDf = pd.DataFrame(index=idx,columns=data.columns)
        # 追加データ新規作成
        insertDf = insertDf.fillna("")
        # 休暇日数は0置換
        insertDf["休暇日数"] = 0
        
        # 日付のみ書換え
        tmpDay = thisMonth
        for i in range(len(idx)):
            insertDf["DateTime"][i] = datetime.date.strftime(tmpDay, '%Y-%m-%d')
            tmpDay = tmpDay + datetime.timedelta(days=1)

        # 休暇マスタが存在するかの分岐
        if (os.path.exists(dataDir+"\\"+tmpTarget+"\\kyukaMst.csv")):
            # "date"列の作成（int型日付）←休暇マスタ結合用
            insertDf["date"] = insertDf["DateTime"].apply(lambda x: x.replace("-", ""))
            insertDf["date"] = insertDf["date"].apply(lambda x: int(x))
            # 休暇マスタ読み込み
            kyukaMst = pd.read_csv(dataDir+"\\"+tmpTarget+"\\kyukaMst.csv", "r", encoding="shift_jis", header=0, delimiter=",")
            kyukaMst['休暇フラグ'] = True
            insertDf = pd.merge(insertDf, kyukaMst, on="date", how="left")
            insertDf["休暇フラグ"][insertDf["休暇フラグ"].isnull()] = False
            
            # 休暇フラグがTrueの行を削除（True以外を残す）
            insertDf = insertDf[insertDf.休暇フラグ != True]
            # 日付型変換
            insertDf['DateTime'] = insertDf["date"].apply(lambda x: pd.to_datetime(str(x), format='%Y%m%d'))
            # 直近の休暇日数
            insertDf["前回日付"] = insertDf["DateTime"].shift(1)
            insertDf["休暇日数"] = insertDf["DateTime"] - insertDf["前回日付"]
            insertDf["休暇日数"] = insertDf["休暇日数"].apply(lambda x: x.days-1)
            
            # work用列の削除
            del insertDf["date"]
            del insertDf["前回日付"]
            del insertDf["休暇フラグ"]

        # 予測用データに結合
        predictionData = predictionData.append(insertDf)
        
        # モデル構築データ出力
        data[data[u'DateTime'] < firstDay].to_csv(dataDir+"\\"+tmpTarget+"\\"+modelingNm, index=False, encoding="shift_jis")
        # 予測データ出力
        predictionData.to_csv(dataDir+"\\"+tmpTarget+"\\"+predicitonNm, index=False, encoding="shift_jis")
